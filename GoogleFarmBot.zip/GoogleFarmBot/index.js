const { Telegraf, Markup, Scenes, session } = require('telegraf');
const { bottoken } = require('./scenes/config');
const { adminid } = require('./scenes/config');
const bot = new Telegraf(bottoken);
const { ref, get, child, set, update } = require('firebase/database');
const db = require('./scenes/bd');
const banscenes = require('./scenes/ban')
const accountscenes = require('./scenes/account')
const rassilkascenes = require('./scenes/rassilka')
const balancescenes = require('./scenes/balance')
const stage = new Scenes.Stage([ accountscenes, balancescenes, rassilkascenes, banscenes ])
bot.use(session());
bot.use(stage.middleware());
bot.command('start', async (ctx) => {
    let value = await get(child(ref(db), "users/" + ctx.chat.id))
    value = value.val();
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if(value == null) {
        await update(child(ref(db), 'users/' + ctx.chat.id), {'username': '@' + ctx.chat.username, 'balance': 0, 'id': '', 'account': '', 'password': '', 'ban': 0})
    } 
    if (ctx.chat.id == adminid) {
        ctx.reply('Привет админ! Вот меню воркера и твоя личная админ-панель.', {
            reply_markup: {
                keyboard: [
                    [
                        {text: '💰 Зарегистрировать аккаунт'},
                        {text: '🧰 Личный кабинет'}
                    ],
                    [
                        {text: '🔈 Информация'},
                        {text: '💬 Помощь'}
                    ],
                    [
                        {text: '🔰 Админ-панель'}
                    ],
                ], resize_keyboard: true
            }
        })
    } 
    if (ban == 1) {
        ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
    } 
    if (ctx.chat.id != adminid && ban != 1) {
            await ctx.reply('Регистрируйте аккаунты Gmail и получайте за это оплату.\n\nКаждый аккаунт оценивается в 10 ₽\n\nВсе очень просто, вы регистрируете аккаунт и сдаете боту. Мы проверяем и выплачиваем вам деньги.', {
                reply_markup: {
                    keyboard: [
                        [
                            {text: '💰 Зарегистрировать аккаунт'},
                            {text: '🧰 Личный кабинет'}
                        ],
                        [
                            {text: '🔈 Информация'},
                             {text: '💬 Помощь'}
                        ],
                    ], resize_keyboard: true
                }
            })
    }
})
bot.hears('💰 Зарегистрировать аккаунт', async (ctx) => {
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if(ban == 1) {
    ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
    } else {
    const inkeyboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: '☑️Согласен', callback_data: 'aprove'}
                ],
                [
                    {text: '❌Закрыть', callback_data: 'close'}
                ],
            ],
        }, parse_mode: 'Markdown'
    }
    ctx.reply('*Инструкция:*\n\n`1.Для того чтобы зарегистрировать аккаунт нужно перейти на `https://accounts.google.com/signup`\n\n2.Вводите Имя и Фамилию (нужно вводить настоящие, если будет набор букв - отказ от выплаты)\n\n3.Придумываете почту (должна быть похожей на настоящую, набор букв также не принимается)\n\n4.Отправляете боту аккаунт и ждете выплаты`\n\nНажми на кнопку "Согласен"', inkeyboard)
}})
bot.hears('🔰 Админ-панель', async (ctx) => {
    if (ctx.chat.id == adminid) {
        const inkeboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: 'Статистика пользователей', callback_data: 'statisticks'}
                    ],
                    [
                        {text: 'Выдать деньги за аккаунт', callback_data: 'moneyforacc'}
                    ],
                    [
                        {text: 'Сделать рассылку', callback_data: 'rassilka'}
                    ],
                    [
                        {text: 'Заблокировать юзера', callback_data: 'ban'}
                    ]
                ]
            }
        }
        ctx.reply('⛄️Привет, ' + ctx.chat.first_name + '\n\nВот твоя админ-панель:', inkeboard)
    }
})
bot.action('ban', async (ctx) => ctx.scene.enter('banscenes'))
bot.action('rassilka', async (ctx) => ctx.scene.enter('rassilkascenes'))
bot.action('statisticks', async (ctx) => {
    let users = await get(child(ref(db), "users")).then(users => {
    users = users.val();
    ctx.answerCbQuery('Пользователей в боте: ' + Object.keys(users).length);
    })
})
bot.action('moneyforacc', async (ctx) => ctx.scene.enter('balancescenes'))
bot.action('aprove', async (ctx) => ctx.scene.enter('accountscenes'))
bot.hears('🧰 Личный кабинет', async (ctx) => {
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if (ban == 1) {
    ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
    } else {
    let balance = await get(child(ref(db), "users/" + ctx.chat.id + '/balance/'))
    balance = balance.val();
    const inkeboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: 'Вывести средства', callback_data: 'vivod'}
                ],
            ], 
        }, parse_mode: 'Markdown'
    }
    ctx.reply('*🎩Добро пожаловать в личный кабинет*\n\n🔰Ваш айди: `' + ctx.chat.id + '`\n\n💳Ваш баланс: ' + balance + '\n\n✅Для вывода средств, воспользуйтесь кнопкой ниже', inkeboard)
}})
bot.action('vivod', async (ctx) => {
    const inkeboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: '100 рублей', callback_data: '100'},
                    {text: '500 рублей', callback_data: '500'}
                ],
                [
                    {text: '250 рублей', callback_data: '250'},
                    {text: '1000 рублей', callback_data: '1000'}
                ],
                [
                    {text: '🔙Назад', callback_data: 'nazadprofile'}
                ]
            ]
        }
    }
    ctx.editMessageText('Выберите сумму для вывода:', inkeboard)
})
bot.action('nazadprofile', async (ctx) => {
    let balance = await get(child(ref(db), "users/" + ctx.chat.id + '/balance/'))
    balance = balance.val();
    const inkeboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: 'Вывести средства', callback_data: 'vivod'}
                ],
            ], 
        }, parse_mode: 'Markdown'
    }
    ctx.editMessageText('*🎩Добро пожаловать в личный кабинет*\n\n🔰Ваш айди: `' + ctx.chat.id + '`\n\n💳Ваш баланс: ' + balance + '\n\n✅Для вывода средств, воспользуйтесь кнопкой ниже', inkeboard)
})
bot.action('close', async (ctx) => {
    await ctx.deleteMessage();
    await ctx.reply('Сообщение закрыто')
})
bot.hears('💬 Помощь', async (ctx) => {
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if(ban == 1) {
    ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
    } else {
    ctx.reply('❗️Не писать по вопросам проверки аккаунта\n\n🗣Контакты поддержки - @helperformgz')
}})
bot.hears('🔈 Информация', async (ctx) => {
    const inkeboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: '❌Закрыть', callback_data: 'close'}
                ],
            ],
        }, parse_mode: 'Markdown'
    }
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if(ban == 1) {
    ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
    } else {
    ctx.reply('*🔝Самые распространенные вопросы:*\n\n`▪️Сколько идет проверка аккаунта?`\nВ основном проверка аккаунта занимает от 2 часов до 2 дней\n\n`▪️На какие платежные системы мы выводим?`\nМы выводим на Qiwi, Visa, Mir, Mastercard и YooMoney.\n\n`▪️Сколько аккаунтов может принять бот?`\nБот примет любое количество аккаунтов, которое вы сможете зарегистрировать\n\n`▪️Как избежать блокировки аккаунта Google?`\n-Не входите в аккаунт после регистрации.\n-Не регистрируйте более двух аккаунтов в сутки, из одного браузера.\n-Не используйте VPN.\n\n🤝Надеюсь вы нашли ответ на свой вопрос', inkeboard)
}})
bot.action('100', async (ctx) => {ctx.answerCbQuery('Недостаточно средств для вывода!')})
bot.action('500', async (ctx) => {ctx.answerCbQuery('Недостаточно средств для вывода!')})
bot.action('250', async (ctx) => {ctx.answerCbQuery('Недостаточно средств для вывода!')})
bot.action('1000', async (ctx) => {ctx.answerCbQuery('Недостаточно средств для вывода!')})
console.log('Запустил бота')
bot.launch();