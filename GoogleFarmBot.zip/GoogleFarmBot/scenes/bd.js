const { getDatabase } = require("firebase/database");
const { initializeApp } = require("firebase/app")

const firebaseConfig = {
    apiKey: "AIzaSyBM1EvbHfIYz3HFpUoUmB7MbZIf6zBd-Iw",
    authDomain: "bdforyt.firebaseapp.com",
    projectId: "bdforyt",
    storageBucket: "bdforyt.appspot.com",
    messagingSenderId: "196987028683",
    appId: "1:196987028683:web:6c902d1a19315a3372c74e"
  };
  

const db = getDatabase(initializeApp(firebaseConfig));

module.exports = db;