const { Markup, Composer, Scenes } = require('telegraf')
const { ref, get, child, set, update } = require("firebase/database");
const db = require("./bd");
const banscenes = new Scenes.WizardScene('banscenes', 
   async (ctx) => {
    let banid = ctx.message.text
    if (banid == '-') {
        ctx.reply('Действие отменено')
        ctx.scene.leave()
    } else {
    let idpeople = await get(child(ref(db), "users/" + banid + '/id/'))
    idpeople = idpeople.val();
    let username = await get(child(ref(db), "users/" + banid + '/username/'))
    username = username.val();
    let ban = await get(child(ref(db), "users/" + banid + '/ban/'))
    ban = ban.val();
    let balance = await get(child(ref(db), "users/" + banid + '/balance/'))
    balance = balance.val();
    let gmail = await get(child(ref(db), "users/" + banid + '/account/'))
    gmail = gmail.val();
    let password = await get(child(ref(db), "users/" + banid + '/password/'))
    password = password.val();
    await update(child(ref(db), 'users/' + banid), {'username': username, 'balance': balance, 'id': idpeople, 'account': gmail, 'password': password, 'ban': 1})
    ctx.reply('Успешно забанен')    
    ctx.scene.leave()
}})
banscenes.enter( async (ctx) => {
    ctx.editMessageText('Введите айди кого нужно забанить\n\nДля отмены отправьте "-"');
})
module.exports = banscenes;