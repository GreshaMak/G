const { Markup, Composer, Scenes } = require('telegraf');
const { ref, get, child, set, update } = require("firebase/database");
const db = require("./bd");
const balancescenes = new Scenes.WizardScene('balancescenes', 
   async (ctx) => { 
    var idpeoples = ctx.message.text
    if(idpeoples == '-') {
        ctx.reply('Отменил')
        ctx.scene.leave()
    } else {
    let username = await get(child(ref(db), "users/" + ctx.chat.id + '/username/'))
    username = username.val();
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    let balance = await get(child(ref(db), "users/" + ctx.chat.id + '/balance/'))
    balance = balance.val();
    let gmail = await get(child(ref(db), "users/" + ctx.chat.id + '/account/'))
    gmail = gmail.val();
    let password = await get(child(ref(db), "users/" + ctx.chat.id + '/password/'))
    password = password.val();
    await update(child(ref(db), 'users/' + ctx.chat.id), {'username': '@' + ctx.chat.username, 'balance': balance, 'id': idpeoples, 'account': gmail, 'password': password, 'ban': ban})
    ctx.reply('Введи баланс который надо выдать')
    ctx.wizard.next()
    }
}, async (ctx) => {
    var newbalance = ctx.message.text
    let idpeople = await get(child(ref(db), "users/" + ctx.chat.id + '/id/'))
    idpeople = idpeople.val();
    let username = await get(child(ref(db), "users/" + idpeople + '/username/'))
    username = username.val();
    let ban = await get(child(ref(db), "users/" + idpeople + '/ban/'))
    ban = ban.val();
    let balance = await get(child(ref(db), "users/" + idpeople + '/balance/'))
    balance = balance.val();
    let gmail = await get(child(ref(db), "users/" + idpeople + '/account/'))
    gmail = gmail.val();
    let password = await get(child(ref(db), "users/" + idpeople + '/password/'))
    password = password.val();
    var one = Number(balance)
    var two = Number(newbalance)
    var conecn = one + two
    await update(child(ref(db), 'users/' + idpeople), {'username': username, 'balance': conecn, 'id': idpeople, 'account': gmail, 'password': password, 'ban': ban})
    ctx.telegram.sendMessage(idpeople, '🤝Поздравляю!💰На ваш баланс зачислено +' + newbalance + ' рублей')
    ctx.reply('Деньги успешно отправлены пользователю!')
    ctx.scene.leave()
})
balancescenes.enter( async (ctx) => {
        ctx.editMessageText('Введи айди человека\n\nЕсли хотите отменить, отправьте "-"')
    })
module.exports = balancescenes;