module.exports = {
    'bottoken': '7407675572:AAEw7wcmbl7wQX2Zu_TxipdMESZlmPgXFHw',
    'adminid': '7016182279',
    'channelid': '-1002164849566',
}
