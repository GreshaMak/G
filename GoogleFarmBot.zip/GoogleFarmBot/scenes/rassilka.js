const { Markup, Composer, Scenes } = require('telegraf')
const { ref, get, child, set, update } = require("firebase/database");
const db = require("./bd");
const rassilkascenes = new Scenes.WizardScene('rassilkascenes', 
   async (ctx) => {
    let textrassilki = ctx.message.text
    if (textrassilki == '-') {
        ctx.reply('Рассылка отменена')
        ctx.scene.leave()
    } else {
    let value = await get(child(ref(db), "users/"))
    value = value.val();
    let users = Object.keys(value)
    let i = 0
    for (let id of users) {
    try { 
    await ctx.telegram.sendMessage(id, textrassilki)
    i++
} catch {}
}
ctx.reply('Успешо получили ' + i + ' 👤')
        ctx.scene.leave()
    }})
rassilkascenes.enter( async (ctx) => {
    ctx.editMessageText('Введите текст рассылки\n\nДля отмены рассылки отправьте "-"');
})
module.exports = rassilkascenes;